
package interfacePackage;


public interface ITransactions {
    public void deposit(double amount);
    public void withdraw(double amount);
}
